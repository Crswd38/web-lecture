function sayHello(name){
console.log("Hello");
console.log("Hi");
console.log("name");
}
sayHello("ward");
sayHello("Jibok");
sayHello("mdol");
alert("알람");
const name = prompt("나이를 입력하세요");
console.log(age);
console.log(number(age))
const msg = confirm("로그아웃하시겠습니까?");