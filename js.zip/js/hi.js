// console.log(document)

// console.log(document.getElementById("wrapper-id"));
// console.log(document.getElementsByTagName("h1"));
// console.log(document.getElementsByClassName("h1-wrapper"));

// const title = console.log(document.getElementsByTagName("h1"));
// console.log(title);

// document.querySelector(".h1-wrapper h1")

// document.querySelector("#wrapper-id h1")
// const h1_list = document.querySelectorAll("h1");

// console.log(h1_list[2]);



const title = document.querySelector(".");
title.innerHTML = "tndjq"
